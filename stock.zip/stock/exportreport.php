<?php
session_start();
error_reporting(0);
include("connect.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<head>
<title></title>
<link rel="stylesheet" href="css/style1.css">
</head>
<body>

<center>
<h1>Product Export Report</h1>
<form action="printexport.php" style="margin-top:30px;" method="POST">
<label style="font-size:20px">Category :</label><select name="category" style="width:250px; font-size:20px;" required>
  <option value="">--SELECT--</option>
  <?php
  $fetch = " SELECT (`product_category`) AS 'product_category'
   FROM `category` WHERE username='$username' GROUP BY `product_category`";
  $result=mysqli_query($conn,$fetch);
  while ($row = mysqli_fetch_array($result))
  {
 ?>

  <option value="<?php echo $row['product_category']; ?>"><?php echo $row['product_category']; ?></option>
<?php } ?>
</select><br><br>
<label style="font-size:20px">From : </label>
<input type="date" name="startdate" style="font-size:20px; border-radius:10px;" required>
<label style="font-size:20px"> To : </label>
<input type="date" name="enddate" style="font-size:20px; border-radius:10px;" required><br><br>
<input type="submit" value="Create Report" style="font-size:20px; border-radius:10px;" name="ereport">
</center>
</body>
</html>
<?php
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
if (isset($_POST['ereport'])) {
  $category=$_POST['category'];
  $check="SELECT * FROM exportproduct WHERE username='$username' AND category='$category' AND date
   BETWEEN '$startdate' AND '$enddate' ORDER BY date";
  $report=mysqli_query($conn,$check);
  ?>
  <center>
  <table style="margin-top:50px; width:850px;">
    <th>Product Name</th> <th>Category</th> <th>Date</th> <th>Quantity</th> <th>Price of One Item</th> <th>Total Amount</th>
  <?php
  while ($row = mysqli_fetch_array($report))
  {
    ?>
   <tr><td><center><?php echo $row["pname"];?></center></td><td><center><?php echo $row["category"] ;?></center></td>
    <td><center><?php echo $row["date"] ;?></center></td><td><center><?php echo $row["quantity"] ;?></center></td>
<td><center><?php echo $row["price"] ;?></center></td>
     <td><center><?php echo $row["total"] ;?></center></td></tr>
  <?php } ?>
</table>
</center>
<?php
}
 ?>
