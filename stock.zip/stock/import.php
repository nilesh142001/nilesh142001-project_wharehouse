<?php
session_start();
error_reporting(0);
include("connect.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);
?>

<html>
<head>
  <title>Add Product</title>
  <link rel="stylesheet" href="css/style2.css">
</head>
<body>

  <center>
    <h1>Import Product</h1>
  <div class="category">
    <form class="" action="import.php" method="post">
  <label>Add Category  </label><input type="text" name="category" required>
  <input type="submit" value="add" name="add" >
</form>
  </div>


<form class="" action="" method="post">
  <table>
    <tr>
      <td>Product Name : </td><td><input type="text" name="pname" required></td></tr>
      <tr><td>Category : </td><td><select name="category" style="width:173px; font-size:15px;" required>
        <option value="">--SELECT--</option>
        <?php
        $fetch =  " SELECT (`product_category`) AS 'product_category' FROM `category` WHERE username='$username' GROUP BY `product_category`";
        $result=mysqli_query($conn,$fetch);
        while ($row = mysqli_fetch_array($result))
        {
       ?>

        <option value="<?php echo $row['product_category']; ?>"><?php echo $row['product_category']; ?></option>
      <?php } ?>
      </select></td></tr>
      <tr><td>Date : </td><td><input type="date" name="date" style="width:173px; font-size:15px;" required></td></tr>
      <tr><td>Validation Date : </td><td><input type="date" name="date1" style="width:173px; font-size:15px;" required></td></tr>
      <tr><td>Quantity(In tons) : </td><td><input type="number" name="number" required></td></tr>
      <tr><td>Cost per tons : </td><td><input type="number" name="cost" required></td></tr>
  </table><br>
  <input type="submit" name="import" value="Add Product">
</form>
</center>
</body>
</html>

<?php

$category=$_POST['category'];
if (isset($_POST['add'])) {
  $check="SELECT * FROM CATEGORY WHERE username='$username' AND product_category='$category'";
  $duplicate=mysqli_query($conn,$check);
  if(mysqli_num_rows($duplicate)>0)
  {
    $msg="Category Already Added";
    echo "<script>alert('$msg');</script>";
  }

  else {
  $cate="INSERT INTO category(username,product_category) VALUES('$username','$category')";
  $data=mysqli_query($conn,$cate);
  if ($data) {
    $msg="Category Added Successfully";
    echo "<script>alert('$msg');</script>";
  }
}
}

$pname=$_POST['pname'];
$category=$_POST['category'];
$date=$_POST['date'];
$vdate=$_POST['date1'];
$number=$_POST['number'];
$cost=$_POST['cost'];
$total=$number*$cost;
if (isset($_POST['import'])) {
$query="INSERT INTO importproduct(username,pname,category,date,vdate,quantity,price,total) VALUES('$username','$pname','$category','$date','$vdate','$number','$cost','$total')";
  $sql=mysqli_query($conn,$query);
if ($sql) {
  $msg="Data Added Successfully";
  echo "<script>alert('$msg');</script>";
}
}

 ?>
