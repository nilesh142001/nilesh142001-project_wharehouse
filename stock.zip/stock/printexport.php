<?php
session_start();
error_reporting(0);
include("connect.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<head>
<title></title>
<link rel="stylesheet" href="css/style1.css">
</head>
<body>
  <button style="margin-left:800px;" onclick="myprint()">Print</button>
  <script>
  function myprint() {
    window.print();
  }
  </script>


  <header><center><h1 style="color:#004d99; font-size:40px;">Stock<font color="white">Vista</font></h1>
    <img src="logo1.png" width=70px height=70px style="margin-left:0px;" /img></center><hr>
<center><h2>Export Report</h2></center>
  <?php
  $startdate=$_POST['startdate'];
  $enddate=$_POST['enddate'];
  if (isset($_POST['ereport'])) {
    $category=$_POST['category'];
  $check="SELECT * FROM exportproduct WHERE username='$username' AND category='$category' AND date
   BETWEEN '$startdate' AND '$enddate' ORDER BY date";
  $report=mysqli_query($conn,$check);
  ?>
  <center>
  <table style="margin-top:50px; width:850px;">
    <th style="	background-color:#004d99; color:white;">Product Name</th> <th style="	background-color:#004d99; color:white;">Category</th>
    <th style="	background-color:#004d99; color:white;">Date</th> <th style="	background-color:#004d99; color:white;">Quantity(in tons)</th>
     <th style="	background-color:#004d99; color:white;">Cost per tons</th> <th style="	background-color:#004d99; color:white;">Total Cost</th>
  <?php
  while ($row = mysqli_fetch_array($report))
  {
    ?>
   <tr><td><center><?php echo $row["pname"];?></center></td><td><center><?php echo $row["category"] ;?></center></td>
    <td><center><?php echo $row["date"] ;?></center></td><td><center><?php echo $row["quantity"] ;?></center></td>
<td><center><?php echo $row["price"] ;?></center></td>
     <td><center><?php echo $row["total"] ;?></center></td></tr>
  <?php } }?>

</table>

</center>
</body>
</html>
