<?php
session_start();
error_reporting(0);
include("connect.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<head>

</head>
<body>

  <center>
    <h1>Export Product</h1>
    <form style="float:left;margin-left:200px;" class="" action="" method="post">
      <table>
        <tr>
          <td>Product Name : </td><td><select name="epname" style="width:173px; font-size:15px;" required>
            <option value="">--SELECT--</option>
            <?php
            $fetch ="SELECT (`pname`) AS 'pname' FROM `importproduct` WHERE username='$username' GROUP BY `pname`";
            $result=mysqli_query($conn,$fetch);
            while ($row = mysqli_fetch_array($result))
            {
           ?>

            <option value="<?php echo $row['pname']; ?>"><?php echo $row['pname']; ?></option>
          <?php } ?>
          </select>
        </td></tr>
          <tr><td>Category : </td><td><select name="ecategory" style="width:173px; font-size:15px;" required>
            <option value="">--SELECT--</option>
            <?php
            $fetch =" SELECT (`product_category`) AS 'product_category'
             FROM `category` WHERE username='$username' GROUP BY `product_category`";
            $result=mysqli_query($conn,$fetch);
            while ($row = mysqli_fetch_array($result))
            {
           ?>

            <option value="<?php echo $row['product_category']; ?>"><?php echo $row['product_category']; ?></option>
          <?php } ?>
          </select></td></tr>
          <tr><td>Date : </td><td><input type="date" name="exportdate" style="width:168px; font-size:15px;" required></td></tr>
          <tr><td>Quantity(In tons) : </td><td><input type="number" name="exportnumber" required></td></tr>
          <tr><td>Cost per tons : </td><td><input type="number" name="exportcost" required></td></tr>
      </table><br>
      <input type="submit" name="export" value="Export Product">
    </form><br><br>


    <form class="" action="" method="post">
      <table>
        <tr>



          <tr><td>Category : </td><td><select name="ecategory" style="width:173px; font-size:15px;" required>
            <option value="">--SELECT--</option>
            <?php
            $fetch =" SELECT (`product_category`) AS 'product_category'
             FROM `category` WHERE username='$username' GROUP BY `product_category`";
            $result=mysqli_query($conn,$fetch);
            while ($row = mysqli_fetch_array($result))
            {
           ?>

            <option value="<?php echo $row['product_category']; ?>"><?php echo $row['product_category']; ?></option>
          <?php } ?>
        </select></td> <td><button name="list">List</button></td></tr></table>
        <table border="1px solid" style="border-collapse:collapse; background-color:rgba(255,255,255,0.5);"><th><?php
        $list=$_POST['ecategory'];
        if (isset($_POST['list'])) {
        $get="SELECT * FROM importproduct WHERE username='$username' AND category='$list'";
        $display=mysqli_query($conn,$get);
        echo "Product Name<br>";?>
        </th>
        <tr><td>
        <?php
        while($row=mysqli_fetch_array($display))
        {
          echo "<center>".$row['pname']."</center><br>";
        }
}
        ?>
      </td>
    </tr>
  </table>
    <br>
    </form>

</center>
</body>
</html>
<?php
$epname=$_POST['epname'];
$ecategory=$_POST['ecategory'];
$edate=$_POST['exportdate'];
$enumber=$_POST['exportnumber'];
$ecost=$_POST['exportcost'];
$etotal=$enumber*$ecost;
if (isset($_POST['export'])) {
  $import="INSERT INTO importproduct(username,pname,category,export)
   VALUES('$username','$epname','$ecategory','$enumber')";
     $result=mysqli_query($conn,$import);
$export="INSERT INTO exportproduct(username,pname,category,date,quantity,price,total)
 VALUES('$username','$epname','$ecategory','$edate','$enumber','$ecost','$etotal')";
  $results=mysqli_query($conn,$export);
if ($results) {
  $msg="Export Data Successfully";
  echo "<script>alert('$msg');</script>";
}
}

 ?>
