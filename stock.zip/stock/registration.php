<?php
include('connect.php');
error_reporting(0);

if (isset($_POST['submit']))
 {
   $username=$_POST['username'];
   $contact=$_POST['contact'];
   $email=$_POST['email'];
   $password=$_POST['password'];
   $cpassword=$_POST['cpassword'];
	if($password==$cpassword)
	{
  $check="SELECT * FROM USER_RECORD WHERE username='$username' OR email='$email'";
  $duplicate=mysqli_query($conn,$check);
  if(mysqli_num_rows($duplicate)>0)
  {
    echo "<script>alert('UserName or Email Already Exist');</script>";
  }
  else {
$sql="INSERT INTO user_record(username,contact,email,password)
 VALUES ('$username','$contact','$email','$password') ";
mysqli_query($conn,$sql);
  $msg="Registration Successfully";
  echo "<script> alert('$msg');</script>";
}
}
	else
	{
		$msg="Password not Match";
  echo "<script> alert('$msg');</script>";
	}
}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet"  href="css/style.css"></link>
  </head>
  <body style="	background-image:URL('image/bg0.jpg'); font-family: sans-serif; ">
<center>
      <div class="container">
      <h1>Register</h1>
	  <center><img src="logo.png" width="80px" height="80px"></img></center>
    <form class="" action="" method="post" enctype="multipart/form-data">
    <label>User Name: </label>
    <input type="text" name="username" placeholder="Enter Unique UserName" required><br>
    <label>Contact no.:</label>
    <input type="text" name="contact" placeholder="Enter your number" required><br>

	  <label>E-mail ID:</label>
    <input type="email" name="email" placeholder="E-mail ID" required><br>
    <label>Password:</label>
    <input type="password" name="password" id="pass" placeholder="Enter Password" required><br>
    <label>Confirm Password:</label>
    <input type="password" name="cpassword" id="cpass" placeholder="Confirm Password" required>
	<input type="submit" style="margin-top:20px;" name="submit" value="Submit">
	<a href="login.php" style="margin-top:20px; text-decoration: none;"><button type="button">LogIn</button></a>
  </form>
  </div>
</center>
  </body>
</html>
