<?php
session_start();
error_reporting(0);
include("connect.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);
?>

<html>
<head>
  <title>Add Product</title>
  <link rel="stylesheet" href="css/style1.css">
</head>
<body>

    <center>
    <h1 style=" margin-bottom:50px; margin-top:20px; ">Dashboard</h1>
  <div class="category1">

  </div>
    <form class="" action="" method="post">
      <table width="800px;">
        <th style="	background-color:#004d99; color:white;">Product Name</th> <th style="	background-color:#004d99; color:white;">Category</th>
         <th style="	background-color:#004d99; color:white;">Quantity(in tons)</th> <th style="	background-color:#004d99; color:white;">Validation Date</th>
        <?php
        $data=" SELECT (`pname`) AS 'pname',(`category`) AS 'category',
        SUM(quantity - export) AS `quantity` FROM `importproduct` WHERE username='$username' GROUP BY `pname`";
        $res=mysqli_query($conn,$data);
        while ($row=mysqli_fetch_array($res))
        {
          ?>
         <tr><td><center><?php echo $row["pname"];?></center></td><td><center><?php echo $row["category"] ;?></center></td>
           <td><center><?php echo $row["quantity"];?></center></td><td><center><?php echo $row["vdate"];?></center></td></tr>
       <?php } ?>
      </table>
  </form>

</center>
</body>
</html>

<?php


 ?>
