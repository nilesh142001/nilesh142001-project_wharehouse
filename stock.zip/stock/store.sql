-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 03, 2020 at 10:54 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `username` varchar(30) NOT NULL,
  `product_category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`username`, `product_category`) VALUES
('kamal123', 'wheat'),
('kamal123', 'rice'),
('kamal123', 'barley');

-- --------------------------------------------------------

--
-- Table structure for table `collect`
--

DROP TABLE IF EXISTS `collect`;
CREATE TABLE IF NOT EXISTS `collect` (
  `name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `datamerge`
--

DROP TABLE IF EXISTS `datamerge`;
CREATE TABLE IF NOT EXISTS `datamerge` (
  `username` varchar(30) NOT NULL,
  `productname` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `item` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `export`
--

DROP TABLE IF EXISTS `export`;
CREATE TABLE IF NOT EXISTS `export` (
  `username` varchar(30) NOT NULL,
  `product_category` varchar(30) NOT NULL,
  `pname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exportproduct`
--

DROP TABLE IF EXISTS `exportproduct`;
CREATE TABLE IF NOT EXISTS `exportproduct` (
  `username` varchar(30) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `quantity` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `exportproduct`
--

INSERT INTO `exportproduct` (`username`, `pname`, `category`, `date`, `quantity`, `price`, `total`) VALUES
('kamal123', 'bb000', 'barley', '2020-02-06', 2, 9000, 18000),
('kamal123', 'rr1', 'wheat', '2020-02-06', 3, 10000, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `importproduct`
--

DROP TABLE IF EXISTS `importproduct`;
CREATE TABLE IF NOT EXISTS `importproduct` (
  `username` varchar(30) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `vdate` date NOT NULL,
  `quantity` int(10) NOT NULL,
  `export` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `importproduct`
--

INSERT INTO `importproduct` (`username`, `pname`, `category`, `date`, `vdate`, `quantity`, `export`, `price`, `total`) VALUES
('kamal123', 'brown rice', 'rice', '2020-02-06', '0000-00-00', 5, 0, 10000, 50000),
('kamal123', 'vr-1', 'wheat', '2020-02-05', '0000-00-00', 2, 0, 5000, 10000),
('kamal123', 'bb000', 'barley', '2020-02-02', '0000-00-00', 3, 0, 8000, 24000),
('kamal123', 'bb000', 'barley', '0000-00-00', '0000-00-00', 0, 2, 0, 0),
('kamal123', 'rr1', 'wheat', '2020-02-13', '0000-00-00', 5, 0, 8000, 40000),
('kamal123', 'rr1', 'wheat', '0000-00-00', '0000-00-00', 0, 3, 0, 0),
('kamal123', 'dfdsfdsf', 'wheat', '2020-02-06', '2020-11-13', 3, 0, 5000, 15000);

-- --------------------------------------------------------

--
-- Table structure for table `kamal123`
--

DROP TABLE IF EXISTS `kamal123`;
CREATE TABLE IF NOT EXISTS `kamal123` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `productname` varchar(50) NOT NULL,
  `category` varchar(20) DEFAULT NULL,
  `pdate` varchar(10) DEFAULT NULL,
  `imp_quality` decimal(10,0) DEFAULT NULL,
  `costprice` decimal(15,0) DEFAULT NULL,
  `sellprice` decimal(15,0) DEFAULT NULL,
  `cost_total` decimal(15,0) DEFAULT NULL,
  `exp_quality` decimal(10,0) DEFAULT NULL,
  `sell_total` decimal(20,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_record`
--

DROP TABLE IF EXISTS `user_record`;
CREATE TABLE IF NOT EXISTS `user_record` (
  `username` varchar(35) NOT NULL,
  `contact` decimal(12,0) DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_record`
--

INSERT INTO `user_record` (`username`, `contact`, `email`, `password`) VALUES
('kamal123', '8006105318', 'kamal000@gmail.com', 'kamal000'),
('nilesh123', '8006105318', 'nilesh123@gmail.com', 'nilesh123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
