<?php
session_start();
error_reporting(0);
include("connection.php");
$username=$_SESSION['username'];
if($username==true)
{

}
else {
  header('location:login.php');
}
$query="SELECT * FROM USER_RECORD WHERE username='$username'";
$data=mysqli_query($conn,$query);
$display=mysqli_fetch_array($data);


?>
<!DOCTYPE html>
<head>
<title>STOREVISTA</title>
<link rel="stylesheet" type="text/css" href="css/style.css"></link>
 <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body  style="	background-image:URL('image/bg0.jpg'); font-family: sans-serif; ">
  <div class="box">
<header><img src="logo1.png" width=140px height=140px style="margin-left:80px; float:left;" /img><center><h1 style="color:#004d99">
  Store<font color="white">Vista</font></h1></center>

<h4><?php echo $username; ?><br>
<a href="logout.php" onclick="myAlert()"><button style="background-color:#004d99;">LogOut</logout></a></h4></header>
<div class="side">
<div class="tab2"><a href="dashboard.php" target="iframe_tab"><center>Dashboard</center></a></div>
<div class="tab2"><a href="import.php" target="iframe_tab"><center>Import Product</center></a></div>
<div class="tab2"><a href="export.php" target="iframe_tab"><center>Exported Product</center></a></div>
<div class="tab2"><a href="importreport.php" target="iframe_tab"><center>Print Import Report</center></a></div>
<div class="tab2"><a href="exportreport.php" target="iframe_tab"><center>Print Export Report</center></a></div>

</div>
<div class="frame"><iframe src="dashboard.php" height="490px" width="1005px" name="iframe_tab"></iframe></div>
</div>
</body>
</html>
