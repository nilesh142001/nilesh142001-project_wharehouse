<?php
require('fpdf.php');
include '../connect.php';
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
  $category=$_POST['category'];
  $check="SELECT * FROM importproduct WHERE username='' AND category='$category' AND date
   BETWEEN '$startdate' AND '$enddate' ORDER BY date";
  $report=mysqli_query($conn,$check);

$pdf=new FPDF('p','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B','30');
$pdf->Cell(190,10,'STOCK VISTA',0,1,'C');
$data="SELECT * FROM user_record WHERE username='kamal123' ";
$res=mysqli_query($conn,$data);
while ($row=mysqli_fetch_array($res)) {
$pdf->SetFont('Arial','','15');
$pdf->Cell(190,7,$row['username'],0,1,'R');
$pdf->Cell(190,7,$row['contact'],0,1,'R');
$pdf->Cell(190,7,$row['email'],0,1,'R');
}
$pdf->Cell(190,7,'',0,1,'C');
$pdf->SetFont('Arial','B','12');
$pdf->Cell(35,10,'Product Name',1,0,'C');
$pdf->Cell(30,10,'Category',1,0,'C');
$pdf->Cell(30,10,'Date',1,0,'C');
$pdf->Cell(25,10,'Quantity',1,0,'C');
$pdf->Cell(40,10,'Price of One Item',1,0,'C');
$pdf->Cell(30,10,'Total Amount',1,1,'C');
$data="SELECT * FROM importproduct WHERE username='kamal123' ";
$res=mysqli_query($conn,$data);
while ($row=mysqli_fetch_array($res)) {
$pdf->SetFont('Arial','','12');
$pdf->Cell(35,10,$row['pname'],1,0,'C');
$pdf->Cell(30,10,$row['category'],1,0,'C');
$pdf->Cell(30,10,$row['date'],1,0,'C');
$pdf->Cell(25,10,$row['quantity'],1,0,'C');
$pdf->Cell(40,10,$row['price'],1,0,'C');
$pdf->Cell(30,10,$row['total'],1,1,'C');
}


$pdf->Cell(30,10,$category,1,1,'C');
$pdf->Cell(30,10,$startdate,1,1,'C');
$pdf->Cell(30,10,$enddate,1,1,'C');
$pdf->output();
?>
