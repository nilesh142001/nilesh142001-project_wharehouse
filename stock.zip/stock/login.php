<?php
session_start();
include("connect.php");

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">

    </style>
  </head>
  <body style="	background-image:URL('image/bg0.jpg'); font-family: sans-serif; " ><center>
    <div class="container" style="height:500px; width:500px; border-radius: 10px; margin-top:100px; background-color:rgba(0,0,0,.2">
<div class="logo" style="height:80px; width:300px; border:0px solid; margin-top: 50px; ">
<img src="logo1.png" alt="" style="height:150px; width:150px; margin-top: 50px; margin-bottom:0px;"   >
<h1 style=" margin-top:-20px; margin-bottom:0px;"><font color="#004d99">STORE</font><font color="white">VISTA</font></h1>
</div>



    <form class="" action="login.php" method="post" style="margin-top:200px;">
      <table border="0px solid" style="margin-top:-50px;">
        <tr>
        <td>
      <label style="font-size:20px; ">
        <b>User Name </b></label></td>
      <td><input type="text" style="font-size:20px; border-radius:10px;" name="username" placeholder="Enter Username" required>
      </td></tr><tr>
         <td></td><td></td> </tr><tr> <td></td><td></td> </tr>
      <tr><td><label style="font-size:20px;"><b>Password </b></label></td>
      <td><input type="password" name="password" style="font-size:20px; border-radius:10px;" placeholder="Enter Password" required>
      </td>
      </tr>
        </table>
      <br><br><br>
      <input type="submit" style="font-size:15px; border-radius:10px; " name="submit" value="Submit">
       <input type="reset" style="font-size:15px; border-radius:10px; " name="reset" value="Reset"><br><br>
       Create New Account? <a href="registration.php">SignUp</a>

  </center>
  </body>
</html>
<?php

if(isset($_POST["submit"]))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$query="SELECT * FROM USER_RECORD WHERE username='$username' && password='$password'";
	$data=mysqli_query($conn,$query);
	$total=mysqli_num_rows($data);
	if($total==1)
	{
		$_SESSION['username']=$username ;
		header ("location:home.php") ;

	}
	else
	{
    $msg="Password Incorrect";
		echo "<script> alert('$msg');</script>";
	}
}
 ?>
