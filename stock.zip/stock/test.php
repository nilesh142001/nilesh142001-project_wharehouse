<?php include 'connect.php'; ?>
<!DOCTYPE html>
<head>
<title></title>
</head>
<body>
<center>
<form action="" style="margin-top:50px;" method="POST">
<label style="font-size:25px">Category :</label><select name="category" required>
  <option value="">--SELECT--</option>
  <?php
  $fetch = "SELECT * FROM importproduct";
  $result=mysqli_query($conn,$fetch);
  while ($row = mysqli_fetch_array($result))
  {
 ?>

  <option value="<?php echo $row['category']; ?>"><?php echo $row['category']; ?></option>
<?php } ?>
</select><br><br>
<input type="submit" value="Create" style="font-size:20px; border-radius:10px;" name="ireport">
</center>
</body>
</html>
<?php
if (isset($_POST['ireport'])) {
  $category=$_POST['category'];
  $data="SELECT * FROM importproduct WHERE category='$category'";
  $get=mysqli_query($conn,$data);
  while ($row = mysqli_fetch_array($get)) {
  echo $row["pname"];
  }
  /*if($get)
  {

  $check="SELECT * FROM importproduct WHERE date BETWEEN $date1 AND $date2";
  $report=mysqli_query($conn,$check);
  while ($row = mysqli_fetch_array($report))
  {
    echo $row['pname'];
  }
}*/
}
 ?>
